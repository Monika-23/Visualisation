
# VAST Challenge 2023

To execute and visualize the results,perform the following steps

Installations Required: Node,React and Python

For TASK 1 output, run MC1.py file

For TASK 2 and sub-task of TASK 3,do the following steps

Step 1: In applications such as Visual Studio code Editor , go to dashboard folder in Vast Challenge 2023 folder.Make sure you are in the same folder in terminal.Use cd ../dashboard command.

Step 2: In the terminal, enter "npm start" command

This starts the server on localhost:3000 address

Above steps displays outputs of Task 2 and Subpart of task 3

For TASK 3 output, run MC3.py file

